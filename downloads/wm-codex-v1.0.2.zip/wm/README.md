### WM Skill - 外贸 B2B 智能获客助手

WM 取自“外贸”拼音 `Wai Mao` 的两个首字母。这是一个专为外贸 B2B 场景打造的个人 AI 技能包，辅助外贸业务员完成客户开发与跟进管理。 

当前版本：`1.0.2`。新增美国 Google/ImportYeti 获客选择、分地区社区与通讯渠道流程、CRM 来源及账号证据字段和完整作者署名。详见 [1.0.2 更新说明](RELEASE_NOTES.md)。

<img width="1382" height="1382" alt="ca81b2fa08ac38918e282b8ea3965dd5" src="https://github.com/user-attachments/assets/31244652-d0f9-4da3-ab05-a617df50fef1" />


### 🎯 核心功能

* **找客户 (Lead Generation)**：分析目标市场，挖掘潜在 B2B 买家特征及渠道。
* **写开发信 (Cold Email)**：根据不同市场与产品特点，生成高转化率的个性化开发信。
* **客户激活 (Lead Activation)**：针对沉睡客户或未回复询盘，设计针对性的跟进（Follow-up）话术。
* **背景调查 (Background Check)**：梳理目标公司的官网、社媒、关键决策人（Buyer/CEO）等背景信息。
* **营销战役 (Campaign Strategy)**：规划多渠道营销 Campaign 方案与触达节奏。
* **客户管理 (CRM Assistant)**：协助整理客户画像、分类归档及撰写 CRM 维护日志。

### ⚠️ 运行边界与安全原则

* **不执行自动外联**：本技能仅生成策略、话术、分析报告和邮件文本。**不会**自动调用任何自动化工具向客户发送邮件或拨打电话，所有外联操作需由业务员手动审核并执行。

### 🚀 使用方法

1.0.2 提供 Codex、WorkBuddy 纯 Skill、WorkBuddy 专家版和 SkillHub 压缩包。WorkBuddy 纯 Skill 包不包含专家 Agent、settings 或插件清单；专家版独立包含双语展示资料、头像和 `skills/wm/` 内嵌技能。两者分别按宿主当前技能与专家导入方式安装，不可混用。

本技能已配置本地及云端快捷唤醒。在支持 Skill 加载的编辑器（如 Cursor / VS Code 等 Codex 环境）或 AI 聊天界面中，你可以通过以下方式调用： 

1. **输入快捷指令**： 

  * 输入 `@wm`
  * 或输入 `/wm`
  * Codex 中也可使用 `$wm`
  * 旧版 `@wy` 作为兼容入口保留
2. **下达任务**：在唤醒词后直接输入你的具体外贸需求。

### 💡 使用示例

* `@wm` 帮我背调一下这家印度尼西亚的汽配进口商，分析他们的核心痛点。
* `/wm` 针对超过 3 个月未回复的欧洲工程机械客户，写一封激活跟进信。

### ☕ 赞赏与支持 (Support & Reward)

**耶马** · [a1415112688@foxmail.com](mailto:a1415112688@foxmail.com)

欢迎反馈与交流，共建更好的产品体验。免费不易，打赏随缘；如有定制需求，亦可接洽。
