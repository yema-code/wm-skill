# WM WorkBuddy 专家版

版本：`1.0.2`。这是单角色外贸 B2B 专家包，不是纯 Skill 安装包。分类为销售商务，沿用 WM 外贸获客助手的名称与头像。

## 安装与结构

通过 WorkBuddy 专家导入入口选择本专家 ZIP；若界面要求文件夹，解压后选择包含 `.codebuddy-plugin/plugin.json` 的 `wm/` 目录。请勿把本包作为纯 Skill 导入。

```text
wm/
|-- .codebuddy-plugin/plugin.json
|-- agents/wm.md
|-- avatars/wm.png
|-- settings.json
`-- skills/wm/
    |-- SKILL.md
    |-- skill.json
    |-- references/
    |-- scripts/
    `-- assets/
```

双语名称、职业、简介、三个快捷问题及默认引导语均在专家清单中；`skills` 指向 `./skills/wm`。技能入口、参考资料和脚本放在同一目录内，避免相对链接失效。

## 1.0.2 能力

- 美国 Google、ImportYeti 或组合获客流程。
- 按地区选择行业社区、本地语言搜索式和通讯渠道。
- 客户背调、竞品社媒分析、开发信、激活跟进、Campaign 和 CRM。
- 保存获客来源、国家、语言、业务账号与证据；兼容旧 CRM 数据。
- 作业报告与看板统一作者署名，客户邮件和私信草稿不附推广署名。

完整变更见 [更新说明](skills/wm/RELEASE_NOTES.md)。实时资料依赖宿主联网能力；不内置自动外联或第三方平台 API。专家入口默认预加载 WM，再按任务加载必要参考，不一次读完全部资料。

本包经结构与字段校验；本次没有修改、注册或重新安装本机 WorkBuddy 专家，也未在导入界面完成运行验收。保留原数据库，升级前备份 `.wm/wm.db`。

---
**耶马** · [a1415112688@foxmail.com](mailto:a1415112688@foxmail.com)

欢迎反馈与交流，共建更好的产品体验。免费不易，打赏随缘；如有定制需求，亦可接洽。
